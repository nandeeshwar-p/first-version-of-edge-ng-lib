import { DatePickerModule } from './date-picker.module';

describe('DatePickerModule', () => {
  it('should work', () => {
    expect(new DatePickerModule()).toBeDefined();
  });
});
