import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppComponent } from './app.component';
import { ExcludeSelectedValuePipe } from './exclude-selected-value.pipe';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    ExcludeSelectedValuePipe],
  imports: [
    CommonModule,
    ReactiveFormsModule,
  ],
  exports:[AppComponent,
    ExcludeSelectedValuePipe],
    bootstrap: [AppComponent]
})
export class MultiSelectValueExclusionModule { }
