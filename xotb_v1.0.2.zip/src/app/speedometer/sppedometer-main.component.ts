import { Component } from '@angular/core';

@Component({
  selector: 'app-speedometer',
  templateUrl: './sppedometer-main.component.html',
  styleUrls: [ './sppedometer-main.component.css' ]
})
export class SpeedometerMainComponent  {
  name = 'Angular';
}
