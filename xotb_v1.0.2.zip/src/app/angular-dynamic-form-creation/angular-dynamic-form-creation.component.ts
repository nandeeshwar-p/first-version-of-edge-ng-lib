import { Component } from '@angular/core';

@Component({
  selector: 'app-dynamic-creation',
  templateUrl: './angular-dynamic-form-creation.component.html',
  styleUrls: ['./styles.css','./angular-dynamic-form-creation.component.css']
})
export class DynamicFormComponent {
  title = 'app';
}
