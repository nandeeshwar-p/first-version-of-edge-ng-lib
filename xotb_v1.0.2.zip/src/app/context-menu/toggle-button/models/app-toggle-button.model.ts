export interface Style {
    [key: string]: string;
}
