import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LocateOnMapModule } from './locate-on-map/locate-on-map.module';
import { MultiSelectValueExclusionModule } from './multi-select-value-exclusion/multi-select-value-exclusion.module';
import { AccordionGroupModule } from './accordion-group/accordion-group.module';
import { ModalWindowModule } from './modal-window/modal-window.module';
import { AngularPaginationModule } from './angular-pagination/angular-pagination.module';
import { SpeedometerModule } from './speedometer/speedometer.module';
import { AngularDynamicFormCreationModule } from './angular-dynamic-form-creation/angular-dynamic-form-creation.module';
import { DynamicNgFormCreationFromJSONModule } from './dynamic-ng-form-creation-from-json/dynamic-ng-form-creation-from-json.module';
import { ImageSliderModule } from './image-slider/image-slider.module';
import { IndeterminateTreeStructureModule } from './indeterminate-tree-structure/indeterminate-tree-structure.module';
import { ContextMenuModuleInfo } from './context-menu/context-menu.module';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MultiSelectValueExclusionModule,
    AccordionGroupModule,
    ModalWindowModule,
    AngularPaginationModule,
    SpeedometerModule,
    AngularDynamicFormCreationModule,
    DynamicNgFormCreationFromJSONModule,
    ImageSliderModule,
    IndeterminateTreeStructureModule,
    ContextMenuModuleInfo
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
