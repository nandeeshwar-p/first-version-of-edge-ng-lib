import { QuickDatePickerModule } from './quick-date-picker.module';


describe('QuickDatePickerModule', () => {
  it('should work', () => {
    expect(new QuickDatePickerModule()).toBeDefined();
  });
});
