export interface DateTimeRange {
    fromDateTime: string;
    toDateTime: string;
    id: string;
}
export interface Style {
  [key: string]: string
}