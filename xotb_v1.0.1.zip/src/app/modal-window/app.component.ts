import { Component } from '@angular/core';

@Component({
  selector: 'app-model',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'modal-window';

  public buttonGroup = 'modal-footer';
}
