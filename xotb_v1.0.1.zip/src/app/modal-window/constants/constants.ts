export const HTML_CODES = {
    close: '&#215;'
  };
