import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { FormGeneratorComponent } from './form-generator/form-generator.component';

@NgModule({
  declarations: [
    AppComponent,
    FormGeneratorComponent
   ],
  imports: [
    CommonModule,
    BrowserModule,
    HttpClientModule
    ],
  exports:[
    AppComponent,
    FormGeneratorComponent
     ]
})
export class DynamicNgFormCreationFromJSONModule { }
