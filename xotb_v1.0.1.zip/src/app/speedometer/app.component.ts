import { Component } from '@angular/core';

@Component({
  selector: 'app-speedometer',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  name = 'Angular';
}
