export interface IDropDownOptions {
    mainKey : String,
    subKeys : Array<String>
}
