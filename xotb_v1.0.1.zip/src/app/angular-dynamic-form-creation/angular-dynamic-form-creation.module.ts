import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppComponent } from './app.component';
import { DynamicFormElemComponent } from './dynamic-form-elem/dynamic-form-elem.component';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    DynamicFormElemComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    // HttpClientModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule
  ],
  exports:[
    AppComponent,
    DynamicFormElemComponent
  ]
})
export class AngularDynamicFormCreationModule { }
