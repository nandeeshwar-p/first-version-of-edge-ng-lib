import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-edge',
  templateUrl: './header-edge.component.html',
  styleUrls: ['./header-edge.component.css']
})
export class HeaderEDGEComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
